# Comic Utility AppImage

Download `ComicUtility-1.0-x86_64.AppImage`, enable **Allow executing file as
program** in its Properties, and double-click it. It includes Python, Qt and
the comic conversion dependencies. No separate Python installation is needed.

This build targets Intel/AMD 64-bit Linux with glibc 2.38 or newer (for example,
Ubuntu 24.04 or newer). It is not an ARM, Windows or macOS build. AppImage does
not guarantee operation on every distribution. Older distributions need a
build made on an older compatible base.

If FUSE is unavailable, run:

```sh
./ComicUtility-1.0-x86_64.AppImage --appimage-extract-and-run
```

Updates are manual: download the replacement AppImage from GitHub Releases.
Deleting the AppImage removes the application file. Your comics remain where
you saved them. Automatic menu installation is not included.

## Build from source

Install Python 3.12 with venv support and the system libarchive shared library.
Obtain appimagetool from its official GitHub releases. If it needs FUSE, extract
it with `--appimage-extract` and use the resulting `squashfs-root/AppRun`.

```sh
python3 -m venv .venv-appimage
.venv-appimage/bin/pip install -r requirements.txt PyInstaller==6.22.3
COMIC_PYTHON="$PWD/.venv-appimage/bin/python" \
APPIMAGETOOL=/absolute/path/to/appimagetool \
bash packaging/appimage/build-appimage.sh
```

The script creates `dist/ComicUtility-1.0-x86_64.AppImage`. It runs the bundled
conversion/GUI self-test before packaging. Use a clean build directory for each
release by setting `COMIC_APPIMAGE_BUILD_ROOT` to a new temporary directory.
The build's system libraries determine its actual minimum glibc requirement.
Run `audit_linux_abi.py` on the AppDir and test the final AppImage before release.

For GitHub, upload the AppImage and checksum as **release assets**, rather than
committing the binary to the source repository. Commit `packaging/appimage/`
and this document as the packaging source. The application remains GPL-3.0;
the AppImage contains license notices under `usr/share/comic-utility/`.
