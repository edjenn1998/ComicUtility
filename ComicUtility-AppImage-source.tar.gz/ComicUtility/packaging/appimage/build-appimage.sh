#!/usr/bin/env bash
set -euo pipefail
project_dir=$(cd -- "$(dirname -- "$0")/../.." && pwd)
build_root=${COMIC_APPIMAGE_BUILD_ROOT:-/tmp/comic-appimage-build}
python_bin=${COMIC_PYTHON:-python3}
: "${APPIMAGETOOL:?Set APPIMAGETOOL to an executable appimagetool (or extracted AppRun)}"
mkdir -p "$build_root" "$project_dir/dist"
"$python_bin" -m PyInstaller --noconfirm --clean --onedir --name comic-utility \
  --workpath "$build_root/work" --specpath "$build_root" --distpath "$build_root/dist" \
  --collect-binaries pypdfium2_raw --collect-all PIL \
  --add-binary "$(ldconfig -p | awk '/libarchive.so.13 /{p=$NF} END{print p}'):." \
  "$project_dir/launch.py"
app_dir="$build_root/ComicUtility.AppDir"
mkdir -p "$app_dir/usr/lib/comic-utility" "$app_dir/usr/share/comic-utility"
cp -a "$build_root/dist/comic-utility/." "$app_dir/usr/lib/comic-utility/"
cp "$project_dir/packaging/appimage/AppRun" "$app_dir/AppRun"
chmod +x "$app_dir/AppRun"
cp "$project_dir/packaging/appimage/"*.desktop "$project_dir/packaging/appimage/"*.svg "$app_dir/"
ln -sf io.github.edjenn1998.ComicUtility.svg "$app_dir/.DirIcon"
cp "$project_dir/LICENSE" "$project_dir/licenses.tar.xz" "$app_dir/usr/share/comic-utility/"
"$python_bin" -m pip freeze > "$app_dir/usr/share/comic-utility/python-dependencies.txt"
QT_QPA_PLATFORM=offscreen "$app_dir/AppRun" --self-test
ARCH=x86_64 "$APPIMAGETOOL" "$app_dir" "$project_dir/dist/ComicUtility-1.0-x86_64.AppImage"
